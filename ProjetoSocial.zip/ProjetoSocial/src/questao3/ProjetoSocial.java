package questao3;

public abstract class ProjetoSocial {
    private String nomeProjeto;
    private String descricao;
    private String endereco;
    private String datainicio;
    private String datafim;

    public ProjetoSocial(String nomeProjeto, String descricao, String endereco, String datainicio,String datafim) {
        this.nomeProjeto = nomeProjeto;;
        this.descricao = descricao;
        this.endereco = endereco;
        this.datainicio = datainicio;
        this.datafim = datafim;
    }

    public String getNomeProjeto() {
        return nomeProjeto;
    }

}
