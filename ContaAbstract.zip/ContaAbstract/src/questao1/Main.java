package questao1;

public class Main {
    public static void main(String[] args) {
        Conta cp = new Conta() {
            @Override
            public void imprimeExtrato() {

            }
        };
        cp.setSaldo(2121);
        cp.imprimeExtrato();
    }
}
