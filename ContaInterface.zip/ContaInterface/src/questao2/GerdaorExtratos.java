package questao2;

public class GerdaorExtratos {
    public void geradorConta(Conta conta) {
        System.out.println("Saldo Atual: "+conta.getSaldo());
    }
}
